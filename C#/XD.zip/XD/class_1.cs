using System;

namespace XD{
    class PersonaCabeza
    {
        public Persona Content { get;set; }
        public PersonaCabeza(string H){
            this.Content = new Persona(1,H);
        }

        public void Print(){
            Content.Print();
        }

        public void Reemove(string X){
            if (Content.Nombre == X)
            {   
                Persona temp = Content;
                temp = temp.next;
                Content = temp;
            }
            else
            {
                Content.Remove(X);
            }
        }
    }
}