using System;

namespace XD
{
    class XD
    {
        public static void Main(string[] ARGS){
            PersonaCabeza Cont = new PersonaCabeza("Jose");
            Persona Y = new Persona(2,"Maria");
            Persona Z = new Persona(3,"Mauricio");
            Cont.Content.ADD(Y);
            Cont.Content.next.ADD(Z);
            //
            Console.WriteLine("A quien quiere sacar del party?");
            string capture = Console.ReadLine();
            Cont.Reemove(capture);
            Console.WriteLine();
            Cont.Print();
        }
    }
}