using System;

namespace XD
{
    class Persona
    {
        public string Nombre { get;set; }
        public int Elemento { get;set; }
        public Persona next { get;set; }

        public Persona(int x, string Ap){
            this.Nombre = Ap;
            this.Elemento = x;
        }

        public void Print(){
            Console.WriteLine(this.Nombre);
            if (next != null)
            {
                next.Print();
            }
        }

        public void ADD(Persona P){
            this.next = P;
        }

        public void Remove(string X){
            if (next == null)
            {
                Console.WriteLine("Se acaba de eliminar!");
            }
            else if (next.Nombre == X)
            {
                next = next.next;
            }
            else
            {
                next.Remove(X);
            }
        }
    }
}